// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package org.openqa.selenium.grid.log;

import java.io.OutputStream;
import java.util.Objects;
import java.util.logging.LogRecord;
import java.util.logging.StreamHandler;
import org.jspecify.annotations.Nullable;

class FlushingHandler extends StreamHandler {

  @Nullable private OutputStream out;

  FlushingHandler(OutputStream out) {
    setOutputStream(out);
  }

  @Override
  protected synchronized void setOutputStream(OutputStream out) throws SecurityException {
    super.setOutputStream(out);
    this.out = out;
  }

  @Override
  public synchronized void publish(LogRecord record) {
    super.publish(record);
    flush();
  }

  @Override
  public synchronized void close() throws SecurityException {
    // Avoid closing sysout or syserr
    if (Objects.equals(System.out, out) || Objects.equals(System.err, out)) {
      flush();
    } else {
      super.close();
    }
  }
}
